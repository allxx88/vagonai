// Single source of truth for catalog content.
// Edit this file to update titles, descriptions, specs, images and prices.

window.PROVAGON_STATUS_LABELS = {
  in_stock: "В наличии",
  on_order: "Под заказ",
  after_repair: "После ремонта",
  new: "Новый",
};

window.PROVAGON_STATUS_COLORS = {
  in_stock: "#4ade80",
  on_order: "#facc15",
  after_repair: "#60a5fa",
  new: "#34d399",
};

window.PROVAGON_CATALOG = [
  {
    id: "gondola",
    title: "Полувагоны",
    subtitle: "Универсальная грузовая единица",
    intro:
      "Полувагоны — основа угольной и металлургической логистики. Высокая грузоподъёмность, открытый кузов для навалочных и штучных грузов.",
    image: "images/wagons/poluvagon.png",
    accentColor: "#5eead4",
    wagons: [
      {
        id: "gv-12-132",
        model: "ПВ-12-132",
        description:
          "Универсальный полувагон нового поколения с увеличенным объёмом кузова",
        purpose: "Уголь, руда, металлопрокат, строительные материалы",
        image: "images/wagons/poluvagon.png",
        specs: [
          { label: "Грузоподъёмность", value: "75 т" },
          { label: "Объём кузова", value: "88 м³" },
          { label: "Длина по осям", value: "13 920 мм" },
          { label: "Осность", value: "4" },
          { label: "Скорость", value: "120 км/ч" },
        ],
        status: "in_stock",
        price: "от 4 200 000 ₽",
        categoryId: "gondola",
      },
      {
        id: "gv-12-9745",
        model: "12-9745",
        description:
          "Инновационный полувагон с разгрузочными люками для насыпных грузов",
        purpose: "Уголь, кокс, рудный концентрат",
        image: "images/wagons/gondola-hero.jpg",
        specs: [
          { label: "Грузоподъёмность", value: "69,5 т" },
          { label: "Объём кузова", value: "73,4 м³" },
          { label: "Длина по осям", value: "12 770 мм" },
          { label: "Осность", value: "4" },
          { label: "Тара", value: "22,5 т" },
        ],
        status: "new",
        price: "от 4 800 000 ₽",
        categoryId: "gondola",
      },
      {
        id: "gv-12-9046",
        model: "12-9046",
        description:
          "Полувагон с увеличенным люком для горно-рудной промышленности",
        purpose: "Руда, агломерат, окатыши",
        image: "images/wagons/gondola-hero.jpg",
        specs: [
          { label: "Грузоподъёмность", value: "71 т" },
          { label: "Объём кузова", value: "76 м³" },
          { label: "Длина по осям", value: "13 400 мм" },
          { label: "Осность", value: "4" },
          { label: "Скорость", value: "110 км/ч" },
        ],
        status: "after_repair",
        price: "от 2 900 000 ₽",
        categoryId: "gondola",
      },
    ],
  },
  {
    id: "hopper",
    title: "Хопперы",
    subtitle: "Быстрая разгрузка, высокая производительность",
    intro:
      "Хопперы-зерновозы, минераловозы и цементовозы. Конический бункер обеспечивает самотёчную выгрузку без дополнительного оборудования.",
    image: "images/wagons/hopper.png",
    accentColor: "#93c5fd",
    wagons: [
      {
        id: "hp-19-9855",
        model: "Хоппер-зерновоз 19-9855",
        description:
          "Крытый хоппер для зерновых и зернобобовых культур с системой вентиляции",
        purpose: "Зерно, мука, крупа, семечки, бобовые",
        image: "images/wagons/hopper-hero.jpg",
        specs: [
          { label: "Грузоподъёмность", value: "73,5 т" },
          { label: "Объём кузова", value: "120 м³" },
          { label: "Длина по осям", value: "13 920 мм" },
          { label: "Тара", value: "26,5 т" },
          { label: "Скорость", value: "120 км/ч" },
        ],
        status: "in_stock",
        price: "от 5 100 000 ₽",
        categoryId: "hopper",
      },
      {
        id: "hp-19-3054",
        model: "Хоппер-минераловоз 19-3054",
        description: "Хоппер для минеральных удобрений с нержавеющими люками",
        purpose: "Минеральные удобрения, сода, поташ",
        image: "images/wagons/hopper-hero.jpg",
        specs: [
          { label: "Грузоподъёмность", value: "66 т" },
          { label: "Объём кузова", value: "60 м³" },
          { label: "Длина по осям", value: "12 020 мм" },
          { label: "Тара", value: "24 т" },
          { label: "Материал", value: "Нерж. сталь 12Х18" },
        ],
        status: "on_order",
        price: "По запросу",
        categoryId: "hopper",
      },
    ],
  },
  {
    id: "tanker",
    title: "Цистерны",
    subtitle: "Жидкие грузы любой категории",
    intro:
      "Нефтебензиновые, кислотные, пищевые цистерны. Сертифицированы для перевозки опасных грузов 3–6 класса. Специальные покрытия под заказ.",
    image: "images/wagons/cisterna.png",
    accentColor: "#fbbf24",
    wagons: [
      {
        id: "tn-15-1500",
        model: "Цистерна 15-1500 нефтебензин",
        description:
          "Восьмиосная цистерна повышенной вместимости для нефтепродуктов",
        purpose: "Нефть, дизельное топливо, мазут, бензин",
        image: "images/wagons/tanker-hero.jpg",
        specs: [
          { label: "Грузоподъёмность", value: "120 т" },
          { label: "Объём котла", value: "141,6 м³" },
          { label: "Длина по осям", value: "20 700 мм" },
          { label: "Осность", value: "8" },
          { label: "Давление котла", value: "0,05 МПа" },
        ],
        status: "in_stock",
        price: "от 7 600 000 ₽",
        categoryId: "tanker",
      },
      {
        id: "tn-15-5102",
        model: "Цистерна кислотная 15-5102",
        description:
          "Цистерна из нержавеющей стали для агрессивных химических грузов",
        purpose: "Серная кислота, соляная кислота, щёлочи",
        image: "images/wagons/tanker-hero.jpg",
        specs: [
          { label: "Грузоподъёмность", value: "56,5 т" },
          { label: "Объём котла", value: "36,6 м³" },
          { label: "Длина по осям", value: "12 020 мм" },
          { label: "Осность", value: "4" },
          { label: "Материал котла", value: "12Х18Н10Т" },
        ],
        status: "on_order",
        price: "По запросу",
        categoryId: "tanker",
      },
    ],
  },
  {
    id: "covered",
    title: "Крытые вагоны",
    subtitle: "Защита груза от атмосферных воздействий",
    intro:
      "Универсальные крытые вагоны для штучных, тарных и пакетированных грузов. Укреплённые стены, двери с запором, вентиляционные решётки.",
    image: "images/wagons/kritie.png",
    accentColor: "#a78bfa",
    wagons: [
      {
        id: "kv-11-286",
        model: "КВ-11-286",
        description:
          "Универсальный крытый вагон с усиленным полом для техники и оборудования",
        purpose: "Металлоконструкции, оборудование, промтовары, авто",
        image: "images/wagons/covered-hero.jpg",
        specs: [
          { label: "Грузоподъёмность", value: "68 т" },
          { label: "Объём кузова", value: "138 м³" },
          { label: "Длина кузова", value: "19 620 мм" },
          { label: "Ширина кузова", value: "2 760 мм" },
          { label: "Высота кузова", value: "2 780 мм" },
        ],
        status: "in_stock",
        price: "от 4 500 000 ₽",
        categoryId: "covered",
      },
    ],
  },
  {
    id: "flatcar",
    title: "Платформы",
    subtitle: "Тяжеловесные и негабаритные грузы",
    intro:
      "Универсальные, контейнерные, лесовозные и транспортёрные платформы. Специальные сцепки для сверхдлинных и сверхтяжёлых грузов.",
    image: "images/wagons/platforma.png",
    accentColor: "#f97316",
    wagons: [
      {
        id: "pl-13-9004",
        model: "Платформа 13-9004 контейнерная",
        description:
          "80-футовая контейнерная платформа для перевозки крупнотоннажных контейнеров",
        purpose: "20-, 40-, 45-футовые контейнеры ISO",
        image: "images/wagons/flatcar-hero.jpg",
        specs: [
          { label: "Грузоподъёмность", value: "72 т" },
          { label: "Длина по осям", value: "19 620 мм" },
          { label: "Ширина", value: "3 144 мм" },
          { label: "Тара", value: "22,5 т" },
          { label: "Фитинговые упоры", value: "18 шт" },
        ],
        status: "in_stock",
        price: "от 4 100 000 ₽",
        categoryId: "flatcar",
      },
      {
        id: "pl-13-2118",
        model: "Транспортёр 13-2118",
        description:
          "Многоосный транспортёр для перевозки крупногабаритных и тяжёлых грузов",
        purpose: "Трансформаторы, реакторы, турбины, пресса",
        image: "images/wagons/flatcar-hero.jpg",
        specs: [
          { label: "Грузоподъёмность", value: "220 т" },
          { label: "Осность", value: "16" },
          { label: "База", value: "18 000 мм" },
          { label: "Тара", value: "160 т" },
          { label: "Скорость", value: "80 км/ч" },
        ],
        status: "on_order",
        price: "По запросу",
        categoryId: "flatcar",
      },
    ],
  },
  {
    id: "dumpcar",
    title: "Думпкары",
    subtitle: "Карьерная и горная логистика",
    intro:
      "Вагоны-самосвалы для горнодобывающей отрасли. Гидравлический или пневматический привод опрокидывания. Работают в условиях Крайнего Севера.",
    image: "images/wagons/dumpkar.png",
    accentColor: "#fb7185",
    wagons: [
      {
        id: "dk-33-682",
        model: "Думпкар 33-682",
        description:
          "Вагон-самосвал с одно- и двухсторонним опрокидыванием для горнорудных предприятий",
        purpose: "Руда, порода, уголь, вскрышные материалы",
        image: "images/wagons/dumpcars-hero.jpg",
        specs: [
          { label: "Грузоподъёмность", value: "105 т" },
          { label: "Объём кузова", value: "42 м³" },
          { label: "Угол опрокидывания", value: "45°" },
          { label: "Осность", value: "8" },
          { label: "Привод", value: "Пневматический" },
        ],
        status: "in_stock",
        price: "от 8 900 000 ₽",
        categoryId: "dumpcar",
      },
    ],
  },
  {
    id: "special",
    title: "Специализированные",
    subtitle: "Нестандартные задачи — точные решения",
    intro:
      "Автомобилевозы, рефрижераторы, скотовозы, вагоны для стекла и металлических рулонов. Проектирование под задачу клиента.",
    image: "images/wagons/covered-hero.jpg",
    accentColor: "#67e8f9",
    wagons: [
      {
        id: "sp-avto-11-9862",
        model: "Автомобилевоз 11-9862",
        description: "Двухъярусный вагон для перевозки легковых автомобилей",
        purpose: "Легковые автомобили класса B–E",
        image: "images/wagons/covered-hero.jpg",
        specs: [
          { label: "Вместимость", value: "8–12 авто" },
          { label: "Грузоподъёмность", value: "38 т" },
          { label: "Длина по осям", value: "24 700 мм" },
          { label: "Ярусность", value: "2" },
          { label: "Загрузка", value: "Торцевая/боковая" },
        ],
        status: "on_order",
        price: "По запросу",
        categoryId: "special",
      },
    ],
  },
  {
    id: "parts",
    title: "Запасные части",
    subtitle: "Комплектующие и сервис",
    intro:
      "Тележки ЦНИИ-Х3, колёсные пары, автосцепки, тормозные системы. Оригинальные и сертифицированные аналоги для всех типов вагонов.",
    image: "images/wagons/flatcar-hero.jpg",
    accentColor: "#86efac",
    wagons: [
      {
        id: "pts-18-9855",
        model: "Тележка 18-9855",
        description:
          "Тележка с нагрузкой 25 т/ось для современных вагонов поколения «Тихий»",
        purpose: "Замена тележек полувагонов и крытых вагонов",
        image: "images/wagons/flatcar-hero.jpg",
        specs: [
          { label: "Нагрузка на ось", value: "25 т" },
          { label: "Колея", value: "1520 мм" },
          { label: "База", value: "1850 мм" },
          { label: "Масса", value: "4 800 кг" },
          { label: "Скорость", value: "120 км/ч" },
        ],
        status: "in_stock",
        price: "от 680 000 ₽",
        categoryId: "parts",
      },
    ],
  },
];

window.PROVAGON_AI_SUGGESTIONS = [
  "Нужен хоппер-зерновоз под 10 000 тонн в месяц",
  "Сравни цистерны для нефти 8-осные",
  "Полувагон б/у в наличии до 3 млн рублей",
  "Что выбрать для перевозки контейнеров?",
];
